
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.Scanner;

public class GraphMatrix {

    int edges[][]; 
   
    int numV;
    
    int numE;

    LinearProbingHash<String>  l = new LinearProbingHash<String>(30,2.5);
    
    ListGraph lg;
   
    public GraphMatrix(int V) {
        this.numV = V;
        edges = new int[V][V];
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                edges[i][j] = 0;
            }
        }
    }
    
    public void addingEdge(int from, int to, int weight) {
        edges[from][to] = weight;
    }

    public boolean isAdjacent(int v1, int v2) {
        return (edges[v1][v2] != 0);
    }

    boolean isThereAPath (String fname,String sname)  {
    
        System.out.println(l.numericvalue(fname)); 
        
         int x = l.numericvalue(fname);
        
         System.out.println(l.numericvalue(sname)); 
        
         int y = l.numericvalue(sname);
      
        return lg.isAdjacent(x, y);
    }
    
     int ShortestPathlengthFromTo(String fname, String sname) {
       
       int x = l.numericvalue(fname);
       
       int y = l.numericvalue(sname);
         
      DepthFirstPaths  d = new DepthFirstPaths (lg,x);
       
      BreadthFirstSearch  b = new BreadthFirstSearch (lg,x);       
       
       if (lg.isAdjacent(x, y)){
         
           if (d.pathTo(y).length<b.pathTo(y).length) {
            
               int temp = d.pathTo(y).length;
               
            System.out.println("\n");   
            
               DFSfromto(fname,sname);
               
                System.out.println("\n");   
               
               return temp;
               
         }
      else if (d.pathTo(y).length>b.pathTo(y).length){
             int temp1 = b.pathTo(y).length;
          
             
             BFSfromto(fname,sname);
             
              System.out.println("\n");   
             
           return temp1;
              }
         
      else {
     int temp2 = d.pathTo(y).length;
           
     DFSfromto(fname,sname);
          
      System.out.println("\n");   
     
     return temp2;
      }
         
       }
      
           System.out.println("Infinity ...");
           
           return 0;
       
     }
     
    void ReadFromFile(String filename) throws FileNotFoundException, IOException {

        Scanner scanner = new Scanner(new File(filename));
       
            while (scanner.hasNextLine()) {
        
                l.insert(scanner.nextLine());
        
       } 
            
            l.edgeBuilder(this);
            
            lg=l.lg;
    }
    
      void BFSfromto(String fname, String sname) {
          
          int x = l.numericvalue(fname);
       
          int y = l.numericvalue(sname);
          
          BreadthFirstSearch b = new BreadthFirstSearch(lg,x);
         
            for (int i = 0 ; i < b.pathTo(y).length;i++){
                
                System.out.print(" "+ l.table[b.pathTo(y)[i]]+"-");
                
            }
            
            System.out.print(" "+ l.table[y]);
       
      } 
	void DFSfromto(String fname, String sname)  {
            
            int x = l.numericvalue(fname);
            
            int y = l.numericvalue(sname);
            
            DepthFirstPaths d = new DepthFirstPaths(lg,x);
            
            for (int i = 0 ; i < d.pathTo(y).length;i++){
                
                System.out.print(" "+ l.table[d.pathTo(y)[i]]+"-");
                
            }
            
            System.out.print(" "+ l.table[y]);
            
        }
        
       
        
    void NumberOfVerticesInComponent(String name) {
       
        ConnectedComponents cc = new ConnectedComponents(lg);
        
       cc.dfs(lg, l.numericvalue(name));
        
        System.out.println("Connected component is : "+ cc.count);
      
    }
    
     void printAllPaths(String name,int noVertex, int length){
        
         int v1= l.numericvalue(name);
       
         AllPaths nap= new AllPaths(l,lg,this,v1);
        
         nap.startLengthPath(length, noVertex);
    }
    int numberOfAllPaths(String fname,String sname){
        
        int v1= l.numericvalue(fname);
        
        int v2= l.numericvalue(sname);
       
        AllPaths nap= new AllPaths(l,lg,this,v1);
        
        return nap.startNop(v2);
    }
 
}